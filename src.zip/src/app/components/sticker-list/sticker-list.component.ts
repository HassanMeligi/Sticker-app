import { Component } from '@angular/core';

@Component({
  selector: 'app-sticker-list',
  standalone: true,
  templateUrl: './sticker-list.component.html',
  styleUrls: ['./sticker-list.component.scss']
})
export class StickerListComponent { }
